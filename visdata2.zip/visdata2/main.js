function fetchData(){
fetch("https://randomuser.me")
.then(response =>{
    if(!response.ok){
        throw Error("ERROR");
    }
    return response.json();
})
.then(data =>{
    console.log(data.data);
    const html = data.data.map(user => {
        return `
        <div class="user">
        <p><img src ="$(user.avatar)" alt="$(user.first_name)"/></p>
        <p>Name: $(user.first_name)</p>
        <p>Gender: $(user.gender)<p>
        </div>
        `;
        
    }).join('');
    console.log(html);
    document.querySelector('#app').insertAdjacentHTML('afterbegin', html);

})
.catch(error =>{
console.log(error);
});
}

fetchData();

function postData(){
    fetch("https://randomuser.me")
    .then(response => {
        if (!response.ok){
        throw Error("ERROR");
        }
        return response.json();
    })
    .then(data => {
        console.log(data);
    })
    .catch(error => {
        console.log(error);
    });
}



requestButton.addEventListener("click", addQuote);

